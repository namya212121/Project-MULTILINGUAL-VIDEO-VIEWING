import tkinter as tk

# Create the root window
master = tk.Tk()

# Get the screen width and height
screen_width = master.winfo_screenwidth()
screen_height = master.winfo_screenheight()

# Print the screen width and height
print("Screen Width:", screen_width)
print("Screen Height:", screen_height)

# Start the Tkinter event loop
master.mainloop()
